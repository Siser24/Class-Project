/* History panel, uses stack for previous and future history played 
 * 
 */

import javax.swing.*;

public class History extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
